var saloon = {
    name: "The Fashion Pet",
    address: {
        state: "Vista",
        city: "CA",
        street: "The Fly Dog 1234",
        zip: "23981"
    },
    hours: {
        opening: "9:00 am",
        closing: "9:00 pm"
    },
    pets:[]
}


//Object Constructor!!!

// class Task {
//     constructor(description, priority) {
//         this.d = description;
//         this.p = priority;
//     }
// }
// var task1 = new Task("Play", "High");
// console.log(task1);
// var task2 = new Task("Nails", "Medium");
// console.log(task2);
// var task3 = new Task("Do Homework", "High");
// console.log(task3);

var counter = 0;

class Pet {
    constructor(name, age, gender, breed, service, owner, phone) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.breed = breed;
        this.service = service;
        this.owner = owner;
        this.phone = phone;
        this.id = counter++;
    }
}
// Create pets

var scooby = new Pet("Scooby", 60, "Male", "Dane", "Grooming", "Shagy", "555-555-5555");
saloon.pets.push(scooby);
var scrappy = new Pet("Scrappy", 50, "Male", "Mixed", "Nails cut", "Shaggy", "555-555-5555");
saloon.pets.push(scrappy);
var renosuke = new Pet("Renosuke", 2, "Male", "Akita", "Grooming", "Julian", "555-555-5555");
saloon.pets.push(renosuke);
var tweety = new Pet("Tweety", 60, "Male", "Bird", "Nails cut", "Bugs Bunny", "999-999-9999");
saloon.pets.push(tweety);

// Gets info from form and converts to variables

var txtName = document.getElementById('petName');
var txtAge = document.getElementById('petAge');
var txtGender = document.getElementById('petGender');
var txtBreed = document.getElementById('petBreed');
var txtService = document.getElementById('petService');
var txtOwner = document.getElementById('ownerName');
var txtPhone = document.getElementById('ownerPhone');

// Function for registering a pet.

function register() {
    var thePet = new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value);

    console.log(thePet);
    saloon.pets.push(thePet);

    clear();
    //display();
    displayTable();
}

// Function clears the registered pet.

function clear() {
    txtName.value = ''; // Clearing the input field
    txtAge.value = '';
    txtGender.value = '';
    txtBreed.value = '';
    txtService.value = '';
    txtOwner.value = '';
    txtPhone.value = '';
}

function display() {
    const petSection = document.getElementById('pets');

    var tmp = '';

    for (i = 0; i < saloon.pets.length; i++) {
        tmp += `<div class="pet">
        <h3>${saloon.pets[i].name} </h3>
        <p>Age: ${saloon.pets[i].age} </p>
        <p>Gender: ${saloon.pets[i].gender} </p>
        <p>Breed: ${saloon.pets[i].breed} </p>
        <p>Service: ${saloon.pets[i].service} </p>
        <p>Owner: ${saloon.pets[i].owner} </p>
        <p>Phone: ${saloon.pets[i].phone} </p>
        </div>`
    }
    petSection.innerHTML = tmp;
}

function displayTable() {
    const petTable = document.getElementById('pets-table');

    var tmp = '';

    for (i = 0; i < saloon.pets.length; i++) {
        tmp += `
        <tr id=${saloon.pets[i].id}>
            <td>${saloon.pets[i].name}</td>
            <td>${saloon.pets[i].age}</td>
            <td>${saloon.pets[i].gender}</td>
            <td>${saloon.pets[i].breed}</td>
            <td>${saloon.pets[i].service}</td>
            <td>${saloon.pets[i].owner}</td>
            <td>${saloon.pets[i].phone}</td>
            <td onclick="deletePet(${saloon.pets[i].id})"><button>Delete</button></td>
        </tr>`
    }
    petTable.innerHTML = tmp;
}

function deletePet(id) {
    console.log("delete pet " + id);

    var row = document.getElementById(id); // selected element using id
    row.remove(); // remove element from the HTML

    for (i = 0; i < saloon.pets.length; i++) {
        var indexDelete; // variable to store the position
        if (saloon.pets[i].id === id) { // search for the id
            indexDelete = i; // update the position value
        }
    }

    saloon.pets.splice(indexDelete, 1); // delete the element from the array
}

function init() {
    console.log("app.js");
    //display();
    displayTable();

    //hook events
}
window.onload = init;
